<?php
include 'confiq.php';
$result=$conn->query("SELECT * FROM siswa");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD sekolah</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
   <h1>Daftar Siswa</h1>
   <a href="create.php"><button class="btn-tambah">tambah siswa baru</button></a>
   <table>
    <thead>
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Alamat</th>
            <th>Email</th>
            <th>Aksi</th>
        </tr>
    </thead>
   
        <tbody>
           
        <?php $i=0; ?>
        <?php while($row=$result->fetch_assoc()):?>

                <tr>
                <td><?=$i+1;?></td>
                   
                    <td><?php echo $row['nama'];?></td>
                    <td><?php echo $row['alamat'];?></td>
                    <td><?php echo $row['email'];?></td>
                 
  <td>
    <button class="edit"><a href="edit.php?id=<?php echo $row['id'];?>">Edit</a></button>
    <button class="delete"><a href="delete.php?id=<?php echo $row['id'];?>">Delete</a></button>
  </td>
                </tr>
                </div>
                <?php $i++; ?>
            <?php endwhile; ?>
        </tbody>
    </table>
</body>
</html>
