<?php
include 'confiq.php';

if($_SERVER['REQUEST_METHOD'] == "POST"){
  $nama =$_POST['nama'];
  $alamat =$_POST['alamat'];
  $email =$_POST['email'];

  $stmt =$conn->prepare("INSERT INTO siswa (nama,alamat,email) VALUES(?, ? ,?)");
  $stmt->bind_param("sss", $nama,$alamat,$email);
  $stmt->execute();
  $stmt->close();


  header ("Location: index.php");

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="create.css">
</head>
<body>
  <form method="post">
    <h2>Tambah data siswa</h2>

    <label for="nama">Nama</label>
    <input type="text" id="nama" name="nama" required><br>
    <label for="alamat">Alamat</label>
    <input type="text" id="alamat" name="alamat" required><br>
    <label for="email">Email</label>
    <input type="text" id="email" name="email" required><br>


    <button type="submit" class="save-button">Save</button>
    <button type="button" class="cancel-button" onclick="cancelForm()">Cancel</button>
  </form>

  <script>
    function cancelForm(){
      window.location.href ="index.php";
    }
  </script>
</body>
</html>