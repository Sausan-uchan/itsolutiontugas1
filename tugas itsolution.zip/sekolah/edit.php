<?php
include 'confiq.php';

$id = $_GET['id'];
$result = $conn->query("SELECT * FROM siswa WHERE id=$id");
$row=$result->fetch_assoc();



if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $email = $_POST['email'];
   
    $stmt = $conn->prepare("UPDATE siswa SET nama = ?, alamat = ?, email = ? WHERE id = ?");
    $stmt->bind_param("sssi", $nama, $alamat, $email,  $id);
    $stmt->execute();
    $stmt->close();
    
    header("Location: index.php");
}
?>           
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit siswa</title>
  
    <link rel="stylesheet" href="edit.css">
</head>
<body>

<form method="post">
 <h1>Edit siswa</h1>
    <label for="nama">Nama:</label>
<input type="text" id="nama" name="nama" value="<?php echo $row ['nama'];?>" required>
    <br>
    <label for="alamat">Alamat:</label>
    <input type="text" name="alamat" value="<?php echo $row['alamat']; ?>" required>
    <br>
    <label for="email">Email:</label>
    <input type="text" id="email" name="email" value="<?php echo $row['email']; ?>" required>
    <br>
    
    <button type="submit">Update</button>
    <button type="button" class="cancel-button" onclick="cancelForm()">Cancel</button>
</ul>
</form>

<!-- JavaScript to handle cancel action -->
<script>
function cancelForm() {
    window.location.href = 'index.php';  //Redirect to the desired page
}
</script>
</form>

</body>
</html>
      